Author: Zatarita
Description: SciFi Vent

Feel free to use this in any of your maps if you like to add some decoration!